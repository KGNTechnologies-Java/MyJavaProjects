package com.kgn.springmvcsecurity.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.kgn.springmvcsecurity.util.JwtDecode;



@RestController
public class LoginController {

	/*@RequestMapping(value = {"/"}, method = RequestMethod.GET)
	public ModelAndView welcomePage(@RequestHeader("authorization") String authorization) {
	System.out.println("Welcome==>"+authorization);
	ModelAndView model = new ModelAndView();
	
	model.setViewName("<!DOCTYPE HTML>" +
     "<html>" +
     "<head></head>" +
     "<body>" +
     "Please decode the JWT token <a href = \"https://jwt.io\" target=\"_new\">here</a><br><br>" +
     authorization +
    "</body>" +
     "</html>");
	 model.setViewName("welcomePage");
		return model;
	}*/
	
	@RequestMapping("/")
	public ModelAndView welcomePage(@RequestHeader("authorization") String authorization) {
	System.out.println("Welcome==>"+authorization);
	
	authorization = authorization.substring(7, authorization.length());
	ModelAndView model = new ModelAndView();
	String pageToNavigate="";
	String name="";
	try {
		Map crmap = JwtDecode.jwtConversion(authorization);
		List roleList = new ArrayList();
		roleList=(List)crmap.get("list");
		name = (String) crmap.get("userName");
		
		//name = name.replace('.', ',');
		Iterator it = roleList.iterator();
		while(it.hasNext()){
			if("AdminUser".equalsIgnoreCase((String) it.next())){
				pageToNavigate = "adminPage";
			}else{
				pageToNavigate = "userPage";
			}
			
			
		}
		
	} catch (Exception e) {
		
		 e.printStackTrace();
	}
	/*return "<!DOCTYPE HTML>" +
     "<html>" +
     "<head></head>" +
     "<body>" +
     "Please decode the JWT token <a href = \"https://jwt.io\" target=\"_new\">here</a><br><br>" +
     authorization +
    "</body>" +
     "</html>";*/
	model.setViewName(pageToNavigate);
	model.addObject("names", name);
	return model;
	}

	@RequestMapping(value = {"/homePage"}, method = RequestMethod.GET)
	public ModelAndView homePage() {		
		ModelAndView model = new ModelAndView();
		model.setViewName("homePage");
		return model;
	}
	
	@RequestMapping(value = {"/adminPage"}, method = RequestMethod.GET)
	public ModelAndView adminPage() {
		ModelAndView model = new ModelAndView();
		model.setViewName("adminPage");
		return model;
	}
	
	@RequestMapping(value = {"/userPage"}, method = RequestMethod.GET)
	public ModelAndView userPage() {
		ModelAndView model = new ModelAndView();
		model.setViewName("userPage");
		return model;
	}
	
	@RequestMapping(value = "/loginPage", method = RequestMethod.GET)
	public ModelAndView loginPage(@RequestParam(value = "error",required = false) String error,
	@RequestParam(value = "logout",	required = false) String logout) {
		
		ModelAndView model = new ModelAndView();
		if (error != null) {
			model.addObject("error", "Invalid Credentials provided.");
		}

		if (logout != null) {
			model.addObject("message", "Logged Out");
		}

		model.setViewName("loginPage");
		return model;
	}
	
	@RequestMapping(value = "/loginPage1", method = RequestMethod.POST)
	public ModelAndView loginPages() {
		System.out.println("In loginpage1 controller");
		ModelAndView model = new ModelAndView();
		
		
		model.setViewName("adminPage");
		return model;
	}
	 
}