package com.kgn.springmvcsecurity.controller;


import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class DefaultController {
	
	/*@RequestMapping("/")
    public String get(@RequestHeader("Authorization") String authorization ) {
         //TODO DO NOT EXPOSE THIS DATA IN PRODUCTION!!!
         return "<!DOCTYPE HTML>" +
             "<html>" +
             "<head></head>" +
             "<body>" +
             "Please decode the JWT token <a href = \"https://jwt.io\" target=\"_new\">here</a><br><br>" +
             authorization +
            "</body>" +
             "</html>";
       return authorization;
    }*/
}
