package com.kgn.springmvcsecurity.configuration;


import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpMethod.POST;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;

import com.sap.xs2.security.commons.SAPOfflineTokenServicesCloud;

@Configuration
@EnableWebSecurity
@EnableResourceServer
public class WebSecurityConfig extends ResourceServerConfigurerAdapter {

    private static final String XSAPPNAME = "SpringMVCSecurityApp-C5251932";
    public static final String DISPLAY_SCOPE = XSAPPNAME + ".Display";
    public static final String UPDATE_SCOPE = XSAPPNAME + ".Update";
    
      // configure Spring Security, demand authentication and specific scopes
    @Override
    public void configure(HttpSecurity http) throws Exception {
        String hasScopeUpdate = "#oauth2.hasScope('" + UPDATE_SCOPE + "')";
        String hasScopeDisplay = "#oauth2.hasScope('" + DISPLAY_SCOPE + "')";
      
        super.configure(http);
        // @formatter:off
        http
            .sessionManagement()
                // session is created by approuter
                .sessionCreationPolicy(SessionCreationPolicy.NEVER)
                .and()
            // demand specific scopes depending on intended request
            .authorizeRequests()
                // enable OAuth2 checks
            	.antMatchers("/health").permitAll()
                .antMatchers("/").permitAll()
                .antMatchers(GET, "/*").authenticated()
                .antMatchers("/welcomePage").permitAll()
               /* .antMatchers(POST, "/api/v1.0/ads/**").access(hasScopeUpdate)
                .antMatchers(PUT, "/api/v1.0/ads/**").access(hasScopeUpdate)
                .antMatchers(DELETE, "/api/v1.0/ads/**").access(hasScopeUpdate)*/
                .antMatchers(GET, "/userPage").access(hasScopeDisplay) 
                .antMatchers(GET, "/homePage").access(hasScopeUpdate)
               .antMatchers(GET, "/userPage").authenticated()
               .antMatchers(POST,"/adminPage").permitAll()
                .anyRequest().denyAll(); // deny anything not configured above
        // @formatter:on
    }
    
    
    @Override
    public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
    	/* System.out.println("Configuring ResourceServerSecurityConfigurer ");
         resources.resourceId("dummy").tokenStore(tokenStore);*/
    }
    
    // configure offline verification which checks if any provided JWT was properly signed
    @Bean
    protected SAPOfflineTokenServicesCloud offlineTokenServices() {
        return new SAPOfflineTokenServicesCloud();
    }
    
  
    
}
